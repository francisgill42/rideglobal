<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HostRideController extends Controller
{
    public function index()
    {
        $all_city= (new \App\Models\all_city)->getAll();
        $all_country= (new \App\Models\all_country)->getAll();
        $all_state= (new \App\Models\all_state)->getAll();
        $city_count= (new \App\Models\City)->getAll()->count();
        $country_count= (new \App\Models\Country)->getAll()->count();
        $riders_count= (new \App\Models\Riders)->getAll()->count();
        return view('website.host', compact('all_city','all_country','all_state','city_count','country_count','riders_count'));
    }
}
