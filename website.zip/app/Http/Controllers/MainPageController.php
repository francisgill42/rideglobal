<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contact;

class MainPageController extends Controller
{
     public function index()
     {
         $city= (new \App\Models\City)->getAll()->count();
         $country= (new \App\Models\Country)->getAll()->count();
         $riders= (new \App\Models\Riders)->getAll()->count();

         return view('website.index', compact('city','country', 'riders'));
     }

     public function aboutUs()
     {
         $city= (new \App\Models\City)->getAll()->count();
         $country= (new \App\Models\Country)->getAll()->count();
         $riders= (new \App\Models\Riders)->getAll()->count();

         return view('website.AboutUs', compact('city','country', 'riders'));
     }

     public function Team()
     {
         $city= (new \App\Models\City)->getAll()->count();
         $country= (new \App\Models\Country)->getAll()->count();
         $riders= (new \App\Models\Riders)->getAll()->count();


         return view('website.Team', compact('city','country', 'riders'));
     }
    public function Causes()
    {
        $city= (new \App\Models\City)->getAll()->count();
        $country= (new \App\Models\Country)->getAll()->count();
        $riders= (new \App\Models\Riders)->getAll()->count();


        return view('website.Causes', compact('city','country', 'riders'));
    }
    public function Contact()
    {
        $city= (new \App\Models\City)->getAll()->count();
        $country= (new \App\Models\Country)->getAll()->count();
        $riders= (new \App\Models\Riders)->getAll()->count();

        return view('website.ContactUs', compact('city','country', 'riders'));
    }

    public function SendMail(Request $request)
    {
        \Mail::send( 'contactMail',array(
            'message' => $request->input('message'),

        ), function($message) use ($request){
            $message->from($request->input('mail'));
            $message->to('yousufmachiyara91@gmail.com', 'Admin');
        });
        return redirect()->back()->with(['success' => 'Your Message Submit Successfully']);
    }

    public function RiderLogin()
    {
        $city= (new \App\Models\City)->getAll()->count();
        $country= (new \App\Models\Country)->getAll()->count();
        $riders= (new \App\Models\Riders)->getAll()->count();

        return view('website.Login', compact('city','country', 'riders'));
    }

}
